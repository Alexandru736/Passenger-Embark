
public class Ticket {
	private String ticket_type;
	
	public Ticket(String ticket_type) {
		this.ticket_type = ticket_type;
	}
	
	public String getTicket_type() {
		return ticket_type;
	}
}
